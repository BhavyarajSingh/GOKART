
<?php
error_reporting(0);
$host ="localhost";//default
$user ="root";//default
$password ="";//not required
$dbname ="userdetail";//databasename
$con=mysqli_connect($host,$user,$password,$dbname); //fn for connecting


 ?>



<!DOCTYPE html>
<html lang="en">
<head>
	<title>GoKart.com</title>
	<link rel="stylesheet" type="text/css" href="GoKart.css">
	<link rel="stylesheet" type="text/css" href="GoKart1.css">
	<link href="https://fonts.googleapis.com/css2?family=Satisfy&display=swap" rel="stylesheet">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.js" charset="utf-8"></script>
	<script src="https://use.fontawesome.com/6e133cc1df.js"></script>
	<link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@1,700&family=Sansita+Swashed:wght@700&display=swap" rel="stylesheet">
	<script src="https://use.fontawesome.com/6e133cc1df.js"></script>
	<link rel="icon" href="Images/android-chrome-512x512.png">
</head>
<body>
<div class="content">
	<div class="head">
	 	<ul class="ul">
	 	<span ><a href="GoKart1.php"><h4>Gokart</h4></a></span>

	 	<li><a href="GoKart1.php">Home</a></li>

	 	<li><a href="Mobiles1.html">Mobiles</a></li>
	    </ul>
	</div>
</body>
<body> <p> <br>  <br><br><br><br> </p></body>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>HTML, CSS Email Contact Form - reusable form</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/skeleton/2.0.4/skeleton.css" >
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <link rel="stylesheet" href="form.css" >
        <script src="form.js"></script>
    </head>
    <body >
        <div class="container">
            <div class="form-container">
                <h1>
                    Feedback form
                </h1>
                <form method="post" id="reused_form" >
                    <label for="name">Your Name:</label>
                    <input id="name" type="text" name="Name" required maxlength="100">
                    <label for="email">Email Address:</label>
                    <input id="email" type="email" name="Email" required maxlength="100">
                    <label for="message">Message:</label>
                    <textarea id="message" name="Message" rows="10" maxlength="100" required></textarea>
                    <button class="button-primary" type="submit" >Post</button>
                </form>
                <div id="success_message" style="display:none">
                    <h3>Submitted the form successfully!</h3>
                    <p> We will get back to you soon. </p>
                </div>
                <div id="error_message" style="width:100%; height:100%; display:none; "> <h3>Error</h3> Sorry there was an error sending your form. </div>
            </div>
        </div>
    </body>
</html>
 <?php
$name=$_POST['Name'];
$email=$_POST['Email'];
$message=$_POST['Message'];

$sql = "INSERT INTO feedback (Name, email,Message) VALUES ('$name', '$email', '$message')";

$query = mysqli_query($con,$sql);
if ($query) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}
?>
