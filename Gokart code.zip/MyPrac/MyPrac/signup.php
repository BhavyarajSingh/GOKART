
<?php
error_reporting(0);
$host ="localhost";//default
$user ="root";//default
$password ="";//not required
$dbname ="userdetail";//databasename
$con=mysqli_connect($host,$user,$password,$dbname); //fn for connecting


$name=$_POST['name'];
$surname=$_POST['surname'];
$email=$_POST['email'];
$password=$_POST['password'];

$sql = "INSERT INTO login (name,surname, email,password) VALUES ('$name', '$surname','$email','$password')";

$query = mysqli_query($con,$sql);
if ($query) {
header("location: newlogin.php");
} else {
  //echo "Error: " . $sql . "<br>" . $conn->error;
}
 ?>
 <!DOCTYPE html>
 <html>
 <head>
 	<title>Sign Up Page</title>
 	<meta charset="UTF-8">
 	<meta name="viewport" content="width=device-width, initial-scale=1">
 	<link rel="stylesheet" type="text/css" href="login.css">
 	<link href="https://fonts.googleapis.com/css2?family=Lobster&display=swap" rel="stylesheet">
 	<link href="https://fonts.googleapis.com/css2?family=Satisfy&display=swap" rel="stylesheet">
 	<script src="https://use.fontawesome.com/6e133cc1df.js"></script>
 	<link rel="icon" href="Images/android-chrome-512x512.png">
 </head>
 <body>
 	<div class="content">
 	  <div class="form sign-up">
 	  	<form action="signup.php" method="post">
 		<h2>Sign up</h2>
 		<label>
 		  <span>First Name</span>
 	     	<input type="name" name="name" id="name">
 		</label>
 		<label>
 		  <span>Last Name</span>
 	     	<input type="surname" name="surname" id="email">
 		</label>
 	    <label>
 		  <span>Email Address</span>
 	     	<input type="email" name="email" >
 		</label>
 		<label>
     	  <span>Password</span>
 			<input type="password" id="password" name="password">
 			<span class="span"><i class="fa fa-eye eye1" aria-hidden="true" id="eye" onclick="toggle()"></i></span>
 		</label>
             <input id="submit" type="submit" name="signup" value="sign-up">
 		</form>
 		</div>
 	<div class="sub-cont">
 		<div class="img">
 			<div class="img-text">
 				<h2>Have been here before?</h2>
 				<p>Login to continue the journey</p>
 			</div>
 			<div class="img-btn">
 	        <a href="newlogin.html"><span style="color: #fff" class="m-up">Login</span></a>
 	       </div>
 		  </div>
 	  </div>
 </div>
 <script>
 	var state= false;
 	function toggle(){
 		if(state){
 			document.getElementById("password").setAttribute("type","password");
 			document.getElementById("eye").style.color='#7a797e';
 			state=false;
 		}
 		else{
 			document.getElementById("password").setAttribute("type","text");
 			document.getElementById("eye").style.color='#5887ef';
 			state=true;
 		}
 	}
 </script>
 </body>
 </html>
