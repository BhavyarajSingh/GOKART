
<?php

// Username is root
$user = 'root';
$password = '';

// Database name is gfg
$database = 'userdetail';

// Server is localhost with
// port number 3308
$servername='localhost';
$mysqli = new mysqli($servername, $user,
                $password, $database);

// Checking for connections
if ($mysqli->connect_error) {
    die('Connect Error (' .
    $mysqli->connect_errno . ') '.
    $mysqli->connect_error);
}

// SQL query to select data from database
$sql = "SELECT * FROM login ";
$result = $mysqli->query($sql);
$mysqli->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<title>GoKart.com</title>
	<link rel="stylesheet" type="text/css" href="GoKart.css">
	<link rel="stylesheet" type="text/css" href="GoKart1.css">
	<link href="https://fonts.googleapis.com/css2?family=Satisfy&display=swap" rel="stylesheet">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.js" charset="utf-8"></script>
	<script src="https://use.fontawesome.com/6e133cc1df.js"></script>
	<link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@1,700&family=Sansita+Swashed:wght@700&display=swap" rel="stylesheet">
	<script src="https://use.fontawesome.com/6e133cc1df.js"></script>
	<link rel="icon" href="Images/android-chrome-512x512.png">
</head>
<body>
<div class="content">
	<div class="head">
	 	<ul class="ul">
	 	<span ><a href="GoKart1.php"><h4>Gokart</h4></a></span>

    <li><a href="adminform.php">Updation</a></li>
	 	<li><a href="GoKart1.php">Home</a></li>
		<li><a href="admin.php">Admin</a></li>

	    </ul>
    </div>
  </div>
</body>
<body> <p> <br>  <br><br><br><br> </p></body>

<head>
    <meta charset="UTF-8">
    <title> User Details</title>
    <!-- CSS FOR STYLING THE PAGE -->
    <style>
        table {
            margin: 0 auto;
            font-size: large;
            border: 1px solid black;
        }

        h1 {
            text-align: center;
            color: #FFA500;
            font-size: xx-large;
            font-family: 'Gill Sans', 'Gill Sans MT',
            ' Calibri', 'Trebuchet MS', 'sans-serif';
        }

        td {
            background-color: #008080;
            border: 1px solid black;
        }

        th,
        td {
            font-weight: bold;
            border: 1px solid black;
            padding: 10px;
            text-align: center;
        }

        td {
            font-weight: lighter;
        }
    </style>
</head>

<body>
    <section>
        <h1>GoKart Users' Information</h1>
        <br>
        <!-- TABLE CONSTRUCTION-->
        <table>
            <tr>
                <th>First Name</th>
                <th>Surname</th>
                <th>Email</th>
                <th>Password</th>
            </tr>
            <!-- PHP CODE TO FETCH DATA FROM ROWS-->
            <?php   // LOOP TILL END OF DATA
                while($rows=$result->fetch_assoc())
                {
             ?>
            <tr>
                <!--FETCHING DATA FROM EACH
                    ROW OF EVERY COLUMN-->
                <td><?php echo $rows['name'];?></td>
                <td><?php echo $rows['surname'];?></td>
                <td><?php echo $rows['email'];?></td>
                <td><?php echo $rows['password'];?></td>
            </tr>
            <?php
                }
             ?>
        </table>
    </section>
</body>


</html>
