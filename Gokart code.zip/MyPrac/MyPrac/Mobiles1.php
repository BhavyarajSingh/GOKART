<!DOCTYPE html>
<html>
<head>
	<title>Mobiles</title>
	<link rel="stylesheet" type="text/css" href="Mobiles.css"/>
	<link rel="stylesheet" type="text/css" href="GoKart.css"/>
	<link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@1,700&family=Sansita+Swashed:wght@700&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=PT+Serif:ital,wght@1,700&display=swap" rel="stylesheet"/>
	<link rel="icon" href="Images/android-chrome-512x512.png">
	<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@700&display=swap" rel="stylesheet">
</head>
<body>
	<div class="head">
		<ul class="ul">
			<span ><a href="GoKart1.php"><h4></h4></a></span>
			<li><a href="GoKart1.php">Home</a></li>
	    </ul>
	</div>
	<!--<div class="line">
		<table>
			<caption><h1>FLAGSHIP</h1></caption>
			<tr>
			<th><div class="container">
				<img src="S20U.jpg" width="325" height="325" class="img"/>
			    <div class="overlay">
				<div class="text"><p>Display: 6.9-inch(1440x3200) 120Hz HDR10+</p><br>
					              <p>Rear Camera: 108+48+12+depth MP</p><br>
					              <p>Front Camera: </p>
					              <p>Battery: 5000mAh</p><br>
					              <p>Processor: Exynos 990</p>
			    </div></div></div></th>
			<th><div class="container">
				<img src="IP11PM.jfif" width="325" height="325" class="img"/>
				<div class="overlay">
				<div class="text"><p>Display: 6.5-inch(1242x2688) 60Hz HDR10</p><br>
					              <p>Rear Camera: 12+12+12 MP</p><br>
					              <p>Front Camera: 12MP</p>
					              <p>Battery: 3969mAh</p><br>
					              <p>Processor: A13 Bionic</p>
			    </div></div></div></th>
			<th><div class="container">
				<img src="OP8P.png" width="325" height="325" class="img"/>
				<div class="overlay">
				<div class="text"><p>Display: 6.78-inch(1440x3168) 120Hz HDR10+</p><br>
					              <p>Rear Camera: 48+8+48+5 MP</p><br>
					              <p>Front Camera: 16MP</p>
					              <p>Battery: 4510mAh</p><br>
					              <p>Processor: Qualcomm Snapdragon 865</p>
				</div></div></div></th>
			<th><div class="container">
				<img src="OX2P.png" width="325" height="325" class="img"/>
				<div class="overlay">
				<div class="text"><p>Display: 6.7(1440x3168) 120Hz HDR10+</p><br>
					              <p>Rear Camera: 48+13+48 MP</p><br>
					              <p>Front Camera: 32MP</p>
					              <p>Battery: 4260mAh</p><br>
					              <p>Processor: Qualcomm Snapdragon 865</p>
				</div></div></div></th>
			</tr>
			<tr>
			<td><p><h2 id="h2">Galaxy S20 Ultra(Cosmic Black)</h2></p>
				<br>
				<p><h3 id="h3">RAM: 12GB/ROM: 256GB</h3></p>
				<br>
			    <p><h4 id="h4">&#x20B9 97,999</h4></p></td>
			<td><p><h2 id="h2">Iphone 11 Pro Max(Midnight Green)</h2></p>
				<br>
				<p><h3 id="h3">RAM: 4GB/ROM: 64GB</h3></p>
				<br>
			    <p><h4 id="h4">&#x20B9 1,17,100</h4></p></td>
			<td><p><h2 id="h2">Oneplus 8 Pro(Glacial Green)</h2></p>
				<br>
				<p><h3 id="h3">RAM: 8GB/ROM: 128GB</h3></p>
				<br>
			    <p><h4 id="h4">&#x20B9 54,999</h4></p></td>
            <td><p><h2 id="h2">Oppo Find X2 Pro(Ceramic Black)</h2></p>
            	<br>
				<p><h3 id="h3">RAM: 12GB/ROM: 256GB</h3></p>
				<br>
			    <p><h4 id="h4">&#x20B9 64,999</h4></p></td>
			</tr>
		</table>
	</div>
	<div class="line2">
		<table>
			<caption><h1>MIDRANGE</h1></caption>
			<tr>
			<th><div class="container">
				<img src="SA71.jpg" width="325" height="325" class="img"/>
			    <div class="overlay">
				<div class="text"><p>Display: 6.7(1080x2400) 60Hz</p><br>
					              <p>Rear Camera: 64+12+5+5 MP</p><br>
					              <p>Front Camera: 32MP</p>
					              <p>Battery: 4500mAh</p><br>
					              <p>Processor: Qualcomm Snapdragon 730</p>
				</div></div></div></th>
			<th><div class="container">
				<img src="IPSE.png" width="325" height="325" class="img"/>
			    <div class="overlay">
				<div class="text"><p>Display: 4.7(750x1334) 60Hz </p><br>
					              <p>Rear Camera: 12 MP</p><br>
					              <p>Front Camera: 7MP</p>
					              <p>Battery: 1821mAh</p><br>
					              <p>Processor: A13 Bionic</p>
				</div></div></div></th>
			<th><div class="container">
				<img src="OPN.png" width="325" height="325" class="img"/>
			    <div class="overlay">
				<div class="text"><p>Display: 6.44(1080x2400) 90Hz HDR10+</p><br>
					              <p>Rear Camera: 48+8+5+2 MP</p><br>
					              <p>Front Camera: 32+8 MP</p>
					              <p>Battery: 4115mAh</p><br>
					              <p>Processor: Qualcomm Snapdragon 765G</p>
				</div></div></div></th>
			<th><div class="container">
				<img src="OR3P.jfif" width="325" height="325" class="img"/>
			    <div class="overlay">
				<div class="text"><p>Display: 6.4(1080x2400) 60Hz</p><br>
					              <p>Rear Camera: 64+13+8+2 MP</p><br>
					              <p>Front Camera: 44MP</p>
					              <p>Battery: 4025mAh</p><br>
					              <p>Processor: Mediatek Helio P95</p>
				</div></div></div></th>
			</tr>
			<tr>
            <td><p><h2 id="h2">Galaxy A71(Prism Cube Black)</h2></p>
            	<br>
				<p><h3 id="h3">RAM: 8GB/ROM: 128GB</h3></p>
				<br>
			    <p><h4 id="h4">&#x20B9 32,999</h4></p></td>
			<td><p><h2 id="h2">Iphone SE 2020(Black)</h2></p>
				<br>
				<p><h3 id="h3">RAM: 3GB/ROM: 128GB</h3></p>
				<br>
			    <p><h4 id="h4">&#x20B9 45,999</h4></p></td>
			<td><p><h2 id="h2">Oneplus Nord(Blue Marble)</h2></p>
				<br>
				<p><h3 id="h3">RAM: 8GB/ROM: 128GB</h3></p>
				<br>
			    <p><h4 id="h4">&#x20B9 27,999</h4></p></td>
			<td><p><h2 id="h2">Oppo Reno 3 Pro(Midnight Black)</h2></p>
				<br>
				<p><h3 id="h3">RAM: 8GB/ROM: 128GB</h3></p>
				<br>
			    <p><h4 id="h4">&#x20B9 29,990</h4></p></td>
			</tr>
		</table>
	</div>

	</div>-->
	<div id="cat">
		<p id="span" value="all" class="active">All</p>
		<p id="sam1" value="Op" >Oneplus</p>
		<p id="sam2" value="Sam" >Samsung</p>
		<p id="sam3" value="Ip" >iPhone</p>
		<p id="sam4" value="Po" >Pixels</p>
	</div>

	<div class="mobiles inverted" id="oneplus">
		<div class="phones inverted">
				<div class="container">
				<img src="Images/OP8T.png" class="inverted" id="oneplus8t">
				<p >Oneplus 8T</p>
				<p>&#x20B9 42,999</p>
				<div class="overlay">
				<div class="text"><p>Display: 6.55-inch(2400x1080) 120Hz HDR10+</p><br>
					              <p>Rear Camera: 48+16+5+2 MP</p><br>
					              <p>Front Camera: 16MP</p>
					              <p>Battery: 4500mAh</p><br>
					              <p>Processor: Qualcomm Snapdragon 865</p>
				</div></div></div>
			</div>
			<div class="phones inverted">
				<div class="container">
				<img src="Images/OP8P.png" class="inverted" id="oneplus8p">
				<p >Oneplus 8 Pro</p>
				<p>&#x20B9 54,999</p>
				<div class="overlay" id="oneplus8p">
				<div class="text"><p id="oneplus8p">Display: 6.78-inch(3168x1440) 120Hz HDR10+</p><br>
					              <p>Rear Camera: 48+8+48+5 MP</p><br>
					              <p>Front Camera: 16MP</p>
					              <p>Battery: 4510mAh</p><br>
					              <p>Processor: Qualcomm Snapdragon 865</p>
				</div></div></div>
			</div>
			<div class="phones inverted">
				<div class="container">
				<img src="Images/OP8.png" class="inverted" alt="oneplus8">
				<p >Oneplus 8</p>
				<p>&#x20B9 44,999</p>
				<div class="overlay">
				<div class="text"><p>Display: 6.55-inch(2400x1080) 90Hz HDR10+</p><br>
					              <p>Rear Camera: 48+2+16 MP</p><br>
					              <p>Front Camera: 16MP</p>
					              <p>Battery: 4300mAh</p><br>
					              <p>Processor: Qualcomm Snapdragon 865</p>
				</div></div></div>
			</div>
			<div class="phones inverted">
				<div class="container">
				<img src="Images/OPN.png" class="inverted" id="oneplusnord">
				<p >Oneplus Nord</p>
				<p>&#x20B9 27,999</p>
				<div class="overlay" id="oneplusnord">
				<div class="text"><p>Display: 6.44-inch(2400x1080) 90Hz</p><br>
					              <p>Rear Camera: 48+8+5+2 MP</p><br>
					              <p>Front Camera: 32MP</p>
					              <p>Battery: 4115mAh</p><br>
					              <p>Processor: Qualcomm Snapdragon 765G 5G</p>
				</div></div></div>
			</div>


	</div>

	<div class="mobiles" id="samsung">
		<div class="phones">
		<div class="container">
				<img src="Images/S20U.jpg" id="samsungs20u">
				<p>Samsung Galaxy S20Ultra</p>
				<p>&#x20B9 97,999</p>
			    <div class="overlay" id="samsungs20u">
				<div class="text"><p>Display: 6.9-inch(3200x1440) 120Hz HDR10+</p><br>
					              <p>Rear Camera: 108+48+12 MP+depth</p><br>
					              <p>Front Camera: 40MP</p>
					              <p>Battery: 5000mAh</p><br>
					              <p>Processor: Exynos 990</p>
			    </div></div></div>
		</div>
		<div class="phones inverted">
			<div class="container">
				<img src="Images/S20P1.jpeg" id="samsungs20p">
				<p>Samsung Galaxy S20+</p>
				<p>&#x20B9 83,000</p>
			    <div class="overlay">
				<div class="text"><p>Display: 6.7-inch(1440x3200) 120Hz HDR10+</p><br>
					              <p>Rear Camera: 12+12+64 MP+depth</p><br>
					              <p>Front Camera: 10MP</p>
					              <p>Battery: 4500mAh</p><br>
					              <p>Processor: Exynos 990</p>
			    </div></div></div>
		</div>
			<div class="phones inverted">
				<div class="container">
				<img src="Images/S20P.jpeg" class="inverted" id="samsungs20p">
				<p >Samsung Galaxy S20</p>
				<p>&#x20B9 70,999</p>
				<div class="overlay">
				<div class="text"><p>Display: 6.2-inch(3200x1440) 120Hz HDR10+</p><br>
					              <p>Rear Camera: 12+64+12 MP</p><br>
					              <p>Front Camera: 10MP</p>
					              <p>Battery: 4000mAh</p><br>
					              <p>Processor: Exynos 990</p>
				</div></div></div>
			</div>
			<div class="phones inverted">
				<div class="container">
				<img src="Images/Note20u1.png" id="samsungnote20u">
				<p >Samsung Galaxy Note20 Utra</p>
				<p >&#x20B9 1,04,999</p>
				<div class="overlay">
				<div class="text"><p>Display: 6.9-inch(3088x1440) 60Hz HDR10</p>
					             `<p>Rear Camera: 108+12+12 MP</p>
					              <p>Front Camera: 10MP</p>
					              <p>Battery: 4500mAh</p>
					              <p>Processor: Exynos 990</p>
			    </div></div></div></div>
	</div>

	<div class="mobiles" id="oneplus">
		<div class="phones inverted">
				<div class="container">
				<img src="Images/OP7TM.png" class="inverted" id="oneplus7tm">
				<p >Oneplus 7T Pro McLaren Edition</p>
				<p>&#x20B9 58,999</p>
				<div class="overlay">
				<div class="text"><p>Display: 6.78-inch(1440x3168) 120Hz HDR10+</p><br>
					              <p>Rear Camera: 48+8+48+5 MP</p><br>
					              <p>Front Camera: 16MP</p>
					              <p>Battery: 4510mAh</p><br>
					              <p>Processor: Qualcomm Snapdragon 865</p>
				</div></div></div>
			</div>
		<div class="phones inverted">
				<div class="container">
				<img src="Images/OP7T.png" class="inverted" id="oneplus7tp">
				<p >Oneplus 7T Pro</p>
				<p>&#x20B9 54,999</p>
				<div class="overlay">
				<div class="text"><p >Display: 6.78-inch(1440x3168) 120Hz HDR10+</p><br>
					              <p>Rear Camera: 48+8+48+5 MP</p><br>
					              <p>Front Camera: 16MP</p>
					              <p>Battery: 4510mAh</p><br>
					              <p>Processor: Qualcomm Snapdragon 865</p>
				</div></div></div>
			</div>
		<div class="phones inverted">
				<div class="container">
				<img src="Images/OP7T1.png" class="inverted" id="oneplus7t">
				<p >Oneplus 7T</p>
				<p>&#x20B9 37,999</p>
				<div class="overlay">
				<div class="text"><p>Display: 6.78-inch(1440x3168) 120Hz HDR10+</p><br>
					              <p>Rear Camera: 48+8+48+5 MP</p><br>
					              <p>Front Camera: 16MP</p>
					              <p>Battery: 4510mAh</p><br>
					              <p>Processor: Qualcomm Snapdragon 865</p>
				</div></div></div>
			</div>
		<div class="phones inverted">
				<div class="container">
				<img src="Images/OP7.png" class="inverted" id="oneplus7" >
				<p >Oneplus 7T Machleren Edition</p>
				<p>&#x20B9 58,999</p>
				<div class="overlay">
				<div class="text"><p>Display: 6.78-inch(1440x3168) 120Hz HDR10+</p><br>
					              <p>Rear Camera: 48+8+48+5 MP</p><br>
					              <p>Front Camera: 16MP</p>
					              <p>Battery: 4510mAh</p><br>
					              <p>Processor: Qualcomm Snapdragon 865</p>
				</div></div></div>
			</div>
	</div>

	<div class="mobiles" id="samsung">
		<div class="phones inverted" id="phones">
			<img src="Images/Note20.jpg" id="samsungnote20">
			<p>Samsung Galaxay Note20</p>
			<p>&#x20B9 77,999</p>
		</div>
			<div class="phones inverteds" id="phones">
				<img src="Images/zfold2.jpg" id="samsungzfold2">
				<p class="">Samsung Galaxy Zfold 2</p>
				<p>&#x20B9 1,49,999</p>
			</div>
			<div class="phones invertedss" id="phones">
				<img src="Images/S20FE.webp"  id="samsungs20fe">
				<p class="">Samsung Galaxy S20FE</p>
				<p>&#x20B9 49,999</p>
			</div>
		<div class="phones invertedsss" id="phones">
			<img src="Images/SA71.jpg" id="samsungsa71">
			<p class="">Samsung</p>
			<p>&#x20B9 29,499</p>
		</div>
	</div>

	<div class="mobiles" id="iphone">
			<div class="phones invertedss" id="phones">
				<img src="Images/IP12M.png"  id="iphone12m">
				<p class="">iPhone 12 Mini</p>
				<p>&#x20B9 69,900</p>
			</div>
			<div class="phones inverteds" id="phones">
				<img src="Images/IP12.png" id="iphone12">
				<p class="">iPhone 12</p>
				<p>&#x20B9 79,900</p>
			</div>
		<div class="phones inverted">
				<div class="container">
				<img src="Images/IP12P.png" id="iphone12p">
				<p >iPhone 12 Pro</p>
				<p >&#x20B9 1,19,900</p>
				<div class="overlay">
				<div class="text"><p>Display: 6.5-inch(1242x2688) 60Hz HDR10</p>
					             `<p>Rear Camera: 12+12+12 MP</p>
					              <p>Front Camera: 12MP</p>
					              <p>Battery: 3969mAh</p>
					              <p>Processor: A13 Bionic</p>
			    </div></div></div></div>
		<div class="phones">
			<div class="container">
				<img src="Images/IP12PM.png" class="image" id="iphone12pm">
				<p>iPhone 12 Pro Max</p>
				<p>&#x20B9 1,29,900</p>
			    <div class="overlay">
				<div class="text"><p>Display: 4.7(750x1334) 60Hz </p><br>
					              <p>Rear Camera: 12 MP</p><br>
					              <p>Front Camera: 7MP</p>
					              <p>Battery: 1821mAh</p><br>
					              <p>Processor: A13 Bionic</p>
				</div></div></div></div>
	</div>

	<div class="mobiles" id="pixel">
		<div class="phones inverted" id="phones">
			<img src="Images/Pixel5p.jpg" id="pixel5">
			<p >Google Pixel 5</p>
			<p >Not In Sale</p>
			<H6>Sales Start Tomorrow</H6>
		</div>
			<div class="phones inverteds" id="phones">
				<img src="Images/p4a.jpg" id="pixel4a">
				<p >Google Pixel 4a</p>
			<p >&#x20B9 29,999</p>
			</div>
			<div class="phones invertedss" id="phones">
				<img src="Images/P3.png"  id="pixel3">
				<p class="">Google Pixel 3</p>
				<p>&#x20B9 24,999</p>
			</div>
		<div class="phones invertedsss" id="phones">
			<img src="Images/P3XL.jpg" id="pixel3xl">
			<p class="">Google Pixel 3XL</p>
		</div>
	</div>

	<div class="mobiles" id="iphone">
			<div class="phones invertedss" id="phones">
				<img src="Images/IP11.png" id="iphone11">
				<p class="">iPhone 11</p>
				<p>&#x20B9 54,900</p>
			</div>
			<div class="phones inverteds" id="phones">
				<img src="Images/IP11p.jpg" id="iphone11p">
				<p class="">iPhone 11 Pro</p>
				<p>&#x20B9 79,900</p>
			</div>
				<div class="phones inverted">
				<div class="container">
				<img src="Images/IP11PM.jfif">
				<p >iPhone 11 Pro Max</p>
				<p >&#x20B9 1,17,100</p>
				<div class="overlay"  id="iphone11pm">
				<div class="text"><p>Display: 6.5-inch(1242x2688) 60Hz HDR10</p>
					             `<p>Rear Camera: 12+12+12 MP</p>
					              <p>Front Camera: 12MP</p>
					              <p>Battery: 3969mAh</p>
					              <p>Processor: A13 Bionic</p>
			    </div></div></div></div>
		<div class="phones">
			<div class="container">
				<img src="Images/IPSE.png" class="image" id="iphonese">
				<p>Iphone SE 2020</p>
				<p>&#x20B9 39,900</p>
			    <div class="overlay">
				<div class="text"><p>Display: 4.7(750x1334) 60Hz </p><br>
					              <p>Rear Camera: 12 MP</p><br>
					              <p>Front Camera: 7MP</p>
					              <p>Battery: 1821mAh</p><br>
					              <p>Processor: A13 Bionic</p>
				</div></div></div></div>
	</div>


<script type="text/javascript">
var cats = document.querySelectorAll("#cat p");
var mobiles = document.querySelectorAll("#oneplus");
var mobile = document.querySelectorAll("#samsung");
var mobile1 = document.querySelectorAll("#iphone");
var mobile2 = document.querySelectorAll("#pixel");
var all = document.querySelectorAll(".mobiles");

cats.forEach((result) => {
	result.addEventListener("click", () =>{
		cats.forEach((result)=>{
			result.classList.remove("active");
		})
		result.classList.add("active");

		var check = result.getAttribute("value");

		all.forEach((all)=> {
				all.style.display="none";
			})

		if(check == "Op"){
			mobiles.forEach((op)=> {
				op.style.display="flex";
			})
		}else if(check == "Sam"){
			mobile.forEach((sam)=> {
				sam.style.display="flex";
			})
		}else if(check == "Ip"){
			mobile1.forEach((ip)=> {
				ip.style.display="flex";
			})
		}else if(check == "Po"){
			mobile2.forEach((po)=> {
				po.style.display="flex";
			})
		}else{
			all.forEach((all)=> {
				all.style.display="flex";
			})
		}
	})
})
</script>
<script type="text/javascript">
	var vals = document.querySelectorAll(".mobiles .phones img,.mobiles .phones .overlay");
	vals.forEach((result) =>{
		result.addEventListener("click", () =>{
			var value = result.getAttribute("id");
			console.log(value);
			localStorage.setItem("myValue", value);
			window.location.href="test.html";
			console.log(value);
		})
	})

</script>

</body>
</html>
