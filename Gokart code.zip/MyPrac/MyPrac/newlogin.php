
<?php
error_reporting(0);
$host ="localhost";//default
$user ="root";//default
$password ="";//not required
$dbname ="userdetail";//databasename
$con=mysqli_connect($host,$user,$password,$dbname); //fn for connecting



$email=$_POST['email'];
$password=$_POST['password'];

$sql = "select * from login where email = '$email' and password = '$password'";
        $result = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
        $count = mysqli_num_rows($result);

        if($count == 1){
            header("Location: GoKart2.php");
        }
        else{
          //  echo "<h1> Login failed. Invalid username or password.</h1>";
        }

 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Login Page</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="login.css">
	<link href="https://fonts.googleapis.com/css2?family=Lobster&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Satisfy&display=swap" rel="stylesheet">
	<script src="https://use.fontawesome.com/6e133cc1df.js"></script>
	<link rel="icon" href="Images/android-chrome-512x512.png">
</head>
<body>
	<div class="content">
	  <div class="form sign-up">
	  	<form action="newlogin.php" method="post">
		<h2>Login</h2>
	    <label>
		  <span>Email Address</span>
	     	<input id="email" type="email" name="email">
		</label>
		<label>
    	  <span>Password</span>
			<input id="password" type="password" name="password">
			<span class="span"><i class="fa fa-eye eye2" aria-hidden="true" id="eye" onclick="toggle()"></i></span>
		</label>
            <input id="submit" type="submit" value="Login" name="login">
		</form>
		</div>
	<div class="sub-cont">
		<div class="img">
			<div class="img-text">
				<h2>New here?</h2>
				<p>Sign up for smoother experience</p>
			</div>
			<div class="img-btn">
	        <a href="signup.html"><span style="color: #fff" class="m-up">Sign up</span></a>
	       </div>
		  </div>
	  </div>
</div>
<script>
	var state= false;
	function toggle(){
		if(state){
			document.getElementById("password").setAttribute("type","password");
			document.getElementById("eye").style.color='#7a797e';
			state=false;
		}
		else{
			document.getElementById("password").setAttribute("type","text");
			document.getElementById("eye").style.color='#5887ef';
			state=true;
		}
	}
</script>
</body>
</html>
