<!DOCTYPE html>
<html>
<head>
	<title>GoKart.com</title>
	<link rel="stylesheet" type="text/css" href="GoKart.css">
	<link rel="stylesheet" type="text/css" href="GoKart1.css">
	<link href="https://fonts.googleapis.com/css2?family=Satisfy&display=swap" rel="stylesheet">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.js" charset="utf-8"></script>
	<script src="https://use.fontawesome.com/6e133cc1df.js"></script>
	<link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@1,700&family=Sansita+Swashed:wght@700&display=swap" rel="stylesheet">
	<script src="https://use.fontawesome.com/6e133cc1df.js"></script>
	<link rel="icon" href="Images/android-chrome-512x512.png">
</head>
<body>
<div class="content">
	<div class="head">
	 	<ul class="ul">
	 	<span ><a href="GoKart1.php"><h4>Gokart</h4></a></span>
			 	<li><a href="GoKart1.php">Home</a></li>
	 	<li><a href="Mobiles1.html">Mobiles</a></li>
	    </ul>
	</div>
	<div class="line">
	<div class="slider">
		<div class="slides ">
			<input type="radio" name="radio-btn" id="radio1">
			<input type="radio" name="radio-btn" id="radio2">
			<input type="radio" name="radio-btn" id="radio3">
			<input type="radio" name="radio-btn" id="radio4">

			<div class="slide first">
				<video autoplay loop muted preload="auto" id="id">
					<source src="Images/note201.mp4" type="video/mp4">
				</video>
			</div>
			<div class="slide">
				<img src="Images/ip11b1.png" class="inverted">
			</div>
			<div class="slide">
				<img src="Images/op8b.jpg" class="inverted">
			</div>
			<div class="slide">
				<img src="Images/Pixel5.jpg" class="inverted">
			</div>
			<div class="navig-auto">
				<div class="auto-btn1"></div>
				<div class="auto-btn2"></div>
				<div class="auto-btn3"></div>
				<div class="auto-btn4"></div>
			</div>
		</div>
		<div class="navig-man">
			<label for="radio1" class="man-btn"></label>
			<label for="radio2" class="man-btn"></label>
			<label for="radio3" class="man-btn"></label>
			<label for="radio4" class="man-btn"></label>
		</div>
	</div>
	</div>
	<div class="mobiles inverted" id="mobiles">
		<div class="phones inverted">
			<a href="test1.php"><img src="Images/S20U0.png" class="inverted" alt="">
			<p>Samsung Galaxy S20Ultra</p>
			<p>&#x20B9 97,999</p></a>
		</div>
			<div class="phones inverted">
				<img src="Images/IP11PM.jfif" class="inverted" alt="">
				<p >iPhone 11 Pro Max</p>
				<p >&#x20B9 1,17,100</p>
			</div>
			<div class="phones inverted">
				<img src="Images/OP8P.png" class="inverted" alt="">
				<p >Oneplus 8 Pro</p>
				<p>&#x20B9 54,999</p>
			</div>
		<div class="phones inverted">
			<img src="Images/Pixel5p.jpg" class="inverted" alt="">
			<p >Google Pixel 5</p>
			<p >Not In Sale</p>
			<H6>Sales Start Tomorrow</H6>
		</div>
	</div>
	<div class="mobiles inverted" id="mobiles">
		<div class="phones inverted">
			<img src="Images/IPSE.png" class="inverted" alt="">
			<p>Iphone SE(2020)</p>
			<p>&#x20B9 39,900</p>
		</div>
			<div class="phones inverted">
				<img src="Images/OPN.png" class="inverted" alt="">
				<p >Oneplus Nord</p>
				<p >&#x20B9 27,999</p>
			</div>
			<div class="phones inverted">
				<img src="Images/S20FE.webp" class="inverted" alt="">
				<p >Samsung Galaxy S20 FE</p>
				<p>&#x20B9 49,999</p>
			</div>
		<div class="phones inverted">
			<img src="Images/p4a.jpg" class="inverted" alt="">
			<p >Google Pixel 4a</p>
			<p >&#x20B9 29,999</p>
		</div>
	</div>
	</div>

	<footer>
		<div class="footer">
			<div class="value">
				<span>GOKART</span>
			</div>
			<div class="value">
				<span>Get To Know Us</span>
				<p class="p"></p>
				<a href=""><p>About Us</p></a>
				<a href="formpage.php"><p>Feedback</p></a>
				<a href="#"><p>Careers</p></a>
			</div>
			<div class="value">
				<span>Contact Us</span>
				<p class="p"></p>
				<a href=""><p><i class="fa fa-phone" aria-hidden="true"></i> Service</p></a>
				<a href="#"><p><i class="fa fa-envelope" aria-hidden="true"></i> Email Us</p></a>
			</div>
			<div class="value">
				<span>Follow Us</span>
				<p class="p"></p>
				<a href="#"><p><i class="fa fa-instagram" aria-hidden="true"> Instagram</i></p></a>
				<a href="#"><p><i class="fa fa-facebook" aria-hidden="true"> Facebook</i></p></a>
				<a href="#"><p><i class="fa fa-twitter" aria-hidden="true"> Twitter</i></p></a>
			</div>
			<div class="value">

				<span>Quick Links</span>
				<p class="p"></p>
				<a href="#"><p>Gift</p></a>
				<a href="#"><p>Promo codes</p></a>
			</div>
		</div>
	</footer>



	<script type="text/javascript">
		var count = 1;
		setInterval(function(){
			document.getElementById('radio' + count).checked= true;
			count++;
			if(count > 4){
				count = 1;
			}

		}, 5900);
		function darkmode(){
			document.documentElement.classList.toggle('dark-mode');
			document.querySelectorAll('.inverted').forEach((result)=>{
				result.classList.toggle('invert');
			})
		}

	</script>
</body>
</html>
