<!DOCTYPE html>
<html>
<head>
	<title></title>

	<link rel="stylesheet" type="text/css" href="GoKart.css">
	<link rel="stylesheet" type="text/css" href="test.css">
	<link rel="icon" href="Images/android-chrome-512x512.png">
	<link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@1,700&family=Sansita+Swashed:wght@700&display=swap" rel="stylesheet">
</head>
<body>
<div class="head">
	 	<ul class="ul">
			<span ><a href="GoKart1.php"><h4>Gokart</h4></a></span>
			<li><a href="GoKart1.php">Home</a></li>
			<li><a href="Mobiles1.php">Mobiles</a></li>
	    </ul>
	</div>
	<div class="cont" id="samsungs20u">
		<div class="row" id="samsungs20u">
			<div class="img mobiles">
				<div class="phones">
				<img src="Images/S20U0.png" value="big" class="big" style="width: 500px; height: 500px;">
			</div>
				<div class="small-img-row">
					<div class="small-img-col">
						<img src="Images/S20U0.png" class="Product active" style=" width: 100px; height: 100px;" id="small-img">
					</div>
					<div class="small-img-col">
						<img src="Images/S20U1.jpg" class="Product" style=" width: 100px; height: 100px;" id="small-img">
					</div>
					<div class="small-img-col">
						<img src="Images/S20U2.jpg" class="Product" style=" width: 100px; height: 100px;" id="small-img">
					</div>
					<div class="small-img-col">
						<img src="Images/S20U3.jpg" class="Product" style=" width: 100px; height: 100px;" id="small-img">
					</div>
				</div>
			</div>
			<div class="line"></div>
			<div class="text">
				<p>Home/Samsung</p>
				<h1>Samsung Galaxy S20Ultra(Cosmic Grey)</h1>
				<h4>&#x20B9 97,999</h4>
				<h3>Key Features: </h3>
				<ul>
					<li>RAM: 12GB/ROM: 256GB</li>
					<li>Display: 6.9-inch(1440x3200) 120Hz HDR10+</li>
					<li>Rear Camera: 108MP+48MP+12MP+depth</li>
					<li>Front Camera: 40MP</li>
					<li>Battery: 5000mAh</li>
					<li>Processor: Exynos 990</li>
				</ul>
			</div>
		</div>
	</div>
		<div class="cont" id="iphone11">
		<div class="row" id="iphone11">
			<div class="img mobiles">
				<div class="phones">
				<img src="Images/IP11.png" value="big" class="big" style="width: 500px; height: 500px;">
			</div>

			<div class="small-img-row">
				<div class="small-img-col">
					<img src="Images/IP11.png" class="Product active" style=" width: 100px; height: 100px;" id="small-img">
				</div>
				<div class="small-img-col">
					<img src="Images/IP11.3.png" class="Product" style=" width: 100px; height: 100px;" id="small-img">
				</div>
				<div class="small-img-col">
					<img src="Images/IP11.1.png" class="Product" style=" width: 100px; height: 100px;" id="small-img">
				</div>
				<div class="small-img-col">
					<img src="Images/IP11.2.png" class="Product" style=" width: 100px; height: 100px;" id="small-img">
				</div>
			</div>
			</div>
			<div class="line"></div>
			<div class="text">
				<p>Home/iPhones</p>
				<h1>iPhone11(Green)</h1>
				<h4>&#x20B9 54,900</h4>
				<h3>Key Features: </h3>
				<ul>
					<li>RAM: 4GB/ROM: 64GB</li>
					<li>Display: 6.1inch(1792 x 828) 60Hz</li>
					<li>Rear Camera: 12+12 MP</li>
					<li>Front Camera: 12MP</li>
					<li>Battery: 3110mAh</li>
					<li>Processor: A13 Bionic</li>
				</ul>
<form><script src="https://checkout.razorpay.com/v1/payment-button.js" data-payment_button_id="pl_Hvf7cjZG6mULoT" async> </script> </form>
		</div>
		<div class="dropdown" id="iphone11">
			<details>
				<summary>Specs</summary>
				<!-- Dimensions -->
					<div class="specs">
						<div class="title">
							<p>Dimensions</p>
						</div>
						<div class="line"></div>
						<div class="detail">
							<p>Height: 124.3 mm</p>
							<p>Width: 74.3 mm</p>
							<p>Thickness: 8.5 mm</p>
							<p>Weight: 199g</p>
						</div>
					</div>
					<div class="line"></div>
					<!-- Display -->
					<div class="specs">
						<div class="title">
							<p>Display</p>
						</div>
						<div class="line"></div>
						<div class="detail">
							<p>Size: 17.22 centimeters (6.78 inches.)</p>
							<p>Resolution: 3168 x 1440 pixels 513 ppi</p>
							<p>Aspect Ratio: 19.8:9</p>
							<p>Type: Fluid AMOLED</p>
							<p>Support sRGB, Display P3</p>
							<p>Cover Glass: 3D Corning Gorilla Glass</p>
						</div>
					</div>
					<div class="line"></div>
					<!-- Perfomance -->
					<div class="specs">
						<div class="title">
							<p>Perfomance</p>
						</div>
						<div class="line"></div>
						<div class="detail">
							<p>Operating System: OxygenOS based on Android™ 10</p>
							<p>CPU: Qualcomm® Snapdragon™ 865</p>
							<p>5G Chipset: X55</p>
							<p>GPU: Adreno 650</p>
							<p>RAM: 8GB/12GB LPDDR5</p>
							<p>Storage: 128GB/256GB UFS 3.0 2-LANE</p>
							<p>Battery: 4510 mAh (non-removable)</p>
							<p>Warp Charge 30T Fast Charging (5V/6A)</p>
							<p>30W Wireless Charging</p>
						</div>
					</div>
					<div class="line"></div>
					<!-- Camera -->
					<div class="specs">
						<div class="title">
							<p>Camera</p>
						</div>
						<div class="line"></div>
						<div class="detail">
							<h4>Rear Camera -  Main</h4>
							<p>Sensor: Sony IMX689</p>
							<p>Megapixels: 48</p>
							<p>Pixel Size: 1.12 µm/48M; 2.24 µm (4 in 1)/12M</p>
							<p>Lens Quantity: 7P</p>
							<p>OIS: Yes</p>
							<p>EIS: Yes</p>
							<p>Aperture: f/1.78</p>
							<h4>Telephoto Lens</h4>
							<p>Megapixels: 8</p>
							<p>Pixel Size: 1.0µm</p>
							<p>OIS: Yes</p>
							<p>Aperture: f/2.44</p>
							<h4>Ultra Wide Angle Lens</h4>
							<p>Megapixels: 48</p>
							<p>Field of View: 120°</p>
							<p>Aperture: f/2.2</p>
							<h4>Color Filter Les</h4>
							<p>Megapixels: 5</p>
							<p>Aperture: f/2.4</p>
							<h4>Video</h4>
							<p>4K video at 30/60 fps</p>
							<p>1080P video at 30/60 fps</p>
							<p>Super Slow Motion: 720p video at 480 fps, 1080p video at 240fps</p>
							<p>Time-Lapse: 1080P 30fps, 4k 30fpss</p>
							<p>Video Editor</p>
							<h4>Front Camera</h4>
							<p>Sensor: Sony IMX471</p>
							<p>Megapixels: 16</p>
							<p>Pixel Size: 1.0</p>
							<p>EIS: Yes</p>
							<p>Autofocus: Fixed Focus</p>
							<p>Aperture: f/2.45</p>
							<h4>Video</h4>
							<p>1080p video at 30fps</p>
							<p>Time-Lapse</p>
						</div>
					</div>
					<div class="line"></div>
					<!-- Connectivity -->
					<div class="specs">
						<div class="title">
							<p>Connectivity</p>
						</div>
						<div class="line"></div>
						<div class="detail">
							<h4>LTE/LTE-A</h4>
							<p>4×4 MIMO, Supports up to DL Cat 18 / UL Cat 13(1.2Gbps / 150Mbps), depending on carrier support</p>
							<h4>Band</h4>
							<p>GSM：GSM850、GSM900、GSM1800、GSM1900</p>
							<p>WCDMA：B1、B2、B4、B5、B8、B9、B19</p>
							<p>CDMA：BC0(Roaming)</p>
							<p>LTE-FDD：B1, 2, 3, 4, 5, 7, 8, 12, 17, 18, 19, 20, 26</p>
							<p>LTE-TDD：B34, 38, 39, 40, 41, 46</p>
							<p>5G: n78</p>
							<p>MIMO：LTE：B1, 3, 41, 40 NR: n78
								（Note：Actual network and frequency band usage depends on local operator deployment. Hardware support 5G n78）</p>
							<h4>Wi-Fi</h4>
							<p>IEEE 802.11 a/b/g/n/ac/ax, 2.4G+5G, 2x2 MIMO</p>
							<h4>Bluetooth</h4>
							<p>Bluetooth 5.1, support aptX & aptX HD & LDAC & AAC & SBC</p>
							<h4>NFC</h4>
							<p>NFC enabled</p>
							<h4>Positioning</h4>
							<p>GPS (L1+L5 Dual Band), GLONASS, Galileo (E1+E5a Dual Band), Beidou, A-GPS</p>
						</div>
					</div>
					<div class="line"></div>
					<!-- Sensors -->
					<div class="specs">
						<div class="title">
							<p>Sensors</p>
						</div>
						<div class="line"></div>
						<div class="detail">
							<p>In-display Fingerprint Sensor</p>
							<p>Accelerometer</p>
							<p>Electronic Compass</p>
							<p>Gyroscope</p>
							<p>Ambient Light Sensor</p>
							<p>Proximity Sensor</p>
							<p>Sensor Core</p>
							<p>Laser Sensor</p>
							<p>Flicker-detect sensor</p>
							<p>Front RGB sensor</p>
						</div>
					</div>
					<div class="line"></div>
					<!-- Ports -->
					<div class="specs">
						<div class="title">
							<p>Ports</p>
						</div>
						<div class="line"></div>
						<div class="detail">
							<p>USB 3.1 GEN1</p>
							<p>Type-C</p>
							<p>Support standard Type-C earphone</p>
							<p>Dual nano-SIM slot</p>
						</div>
					</div>
					<div class="line"></div>
					<!-- Multimedia -->
					<div class="specs">
						<div class="title">
							<p>Multimedia</p>
						</div>
						<div class="line"></div>
						<div class="detail">
							<h4>Audio Supported Formats</h4>
							<p>Playback: MP3, AAC, AAC+, WMA, AMR-NB, AMR-WB, WAV, FLAC, APE, OGG, MID, M4A, IMY, AC3, EAC3, EAC3-JOC, AC4</p>
							<p>Recording: WAV, AAC, AMR</p>
							<h4>Video Supported Formats</h4>
							<p>Playback: MKV, MOV, MP4, H.265(HEVC), AVI, WMV, TS, 3GP, FLV, WEBM</p>
							<p>Recording: MP4</p>
							<h4>Image Supported Formats</h4>
							<p>Playback: JPEG、PNG、BMP、GIF、WEB、HEIF、HEIC、RAW</p>
							<p>Output: JPEG, DNG</p>
						</div>
					</div>
			</details>
		</div>
		<div class="dropdown">
			<details>
				<summary>In The Box</summary>
				<!-- Dimensions -->
				<div class="specs">
					<div class="title">
						<p>In the Box</p>
					</div>
					<div class="line"></div>
					<div class="detail">
						<p>iPhone 11</p>
						<p>Type-C to Lightning Cable</p>
						<p>Quick start guide</p>
					</div>
				</div>
					<div class="Images">
						<img src="Images/IP11.jfif" alt="This Does not Support your browser">
					</div>
			</details>
		</div>
	</div>


	<!-- Third Div -->
	<div class="cont" id="oneplus8p">
		<div class="row" id="oneplus8p">
			<div class="img mobiles">
				<div class="phones">
				<img src="Images/OP8P.png" value="big" class="big" style="width: 500px; height: 500px;">
			</div>
			<div class="small-img-row">
				<div class="small-img-col">
					<img src="Images/OP8P.png" class="Product active" style=" width: 100px; height: 100px;" id="small-img">
				</div>
				<div class="small-img-col">
					<img src="Images/OP8p2.png" class="Product" style=" width: 100px; height: 100px;" id="small-img">
				</div>
				<div class="small-img-col">
					<img src="Images/OP8P1.png" class="Product" style=" width: 100px; height: 100px;" id="small-img">
				</div>
				<div class="small-img-col">
					<img src="Images/OP8p3.png" class="Product" style=" width: 100px; height: 100px;" id="small-img">
				</div>
			</div>
			</div>
			<div class="line"></div>
			<div class="text">
				<p>Mobiles/Oneplus</p>
				<h1>Oneplus 8Pro(Glacier Green)</h1>
				<h4>&#x20B9 49,999</h4>
				<h3>Key Features: </h3>
				<ul>
					<li>Display: 6.78-inch(1440x3168) 120Hz HDR10+</li>
					<li>Rear Camera: 48+8+48+5 MP</li>
					<li>Front Camera: 16MP</li>
					<li>Battery: 4510mAh</li>
					<li>Processor: Qualcomm Snapdragon 865</li>
				</ul>
				<form><script src="https://checkout.razorpay.com/v1/payment-button.js" data-payment_button_id="pl_FuFCSzTKS4OLXN"> </script> </form>
			</div>
		</div>
		<div class="dropdown" id="oneplus8p">
			<details>
				<summary>Specs</summary>
				<!-- Dimensions -->
					<div class="specs">
						<div class="title">
							<p>Dimensions</p>
						</div>
						<div class="line"></div>
						<div class="detail">
							<p>Height: 165.3 mm</p>
							<p>Width: 74.3 mm</p>
							<p>Thickness: 8.5 mm</p>
							<p>Weight: 199g</p>
						</div>
					</div>
					<div class="line"></div>
					<!-- Display -->
					<div class="specs">
						<div class="title">
							<p>Display</p>
						</div>
						<div class="line"></div>
						<div class="detail">
							<p>Size: 17.22 centimeters (6.78 inches.)</p>
							<p>Resolution: 3168 x 1440 pixels 513 ppi</p>
							<p>Aspect Ratio: 19.8:9</p>
							<p>Type: Fluid AMOLED</p>
							<p>Support sRGB, Display P3</p>
							<p>Cover Glass: 3D Corning Gorilla Glass</p>
						</div>
					</div>
					<div class="line"></div>
					<!-- Perfomance -->
					<div class="specs">
						<div class="title">
							<p>Perfomance</p>
						</div>
						<div class="line"></div>
						<div class="detail">
							<p>Operating System: OxygenOS based on Android™ 10</p>
							<p>CPU: Qualcomm® Snapdragon™ 865</p>
							<p>5G Chipset: X55</p>
							<p>GPU: Adreno 650</p>
							<p>RAM: 8GB/12GB LPDDR5</p>
							<p>Storage: 128GB/256GB UFS 3.0 2-LANE</p>
							<p>Battery: 4510 mAh (non-removable)</p>
							<p>Warp Charge 30T Fast Charging (5V/6A)</p>
							<p>30W Wireless Charging</p>
						</div>
					</div>
					<div class="line"></div>
					<!-- Camera -->
					<div class="specs">
						<div class="title">
							<p>Camera</p>
						</div>
						<div class="line"></div>
						<div class="detail">
							<h4>Rear Camera -  Main</h4>
							<p>Sensor: Sony IMX689</p>
							<p>Megapixels: 48</p>
							<p>Pixel Size: 1.12 µm/48M; 2.24 µm (4 in 1)/12M</p>
							<p>Lens Quantity: 7P</p>
							<p>OIS: Yes</p>
							<p>EIS: Yes</p>
							<p>Aperture: f/1.78</p>
							<h4>Telephoto Lens</h4>
							<p>Megapixels: 8</p>
							<p>Pixel Size: 1.0µm</p>
							<p>OIS: Yes</p>
							<p>Aperture: f/2.44</p>
							<h4>Ultra Wide Angle Lens</h4>
							<p>Megapixels: 48</p>
							<p>Field of View: 120°</p>
							<p>Aperture: f/2.2</p>
							<h4>Color Filter Les</h4>
							<p>Megapixels: 5</p>
							<p>Aperture: f/2.4</p>
							<h4>Video</h4>
							<p>4K video at 30/60 fps</p>
							<p>1080P video at 30/60 fps</p>
							<p>Super Slow Motion: 720p video at 480 fps, 1080p video at 240fps</p>
							<p>Time-Lapse: 1080P 30fps, 4k 30fpss</p>
							<p>Video Editor</p>
							<h4>Front Camera</h4>
							<p>Sensor: Sony IMX471</p>
							<p>Megapixels: 16</p>
							<p>Pixel Size: 1.0</p>
							<p>EIS: Yes</p>
							<p>Autofocus: Fixed Focus</p>
							<p>Aperture: f/2.45</p>
							<h4>Video</h4>
							<p>1080p video at 30fps</p>
							<p>Time-Lapse</p>
						</div>
					</div>
					<div class="line"></div>
					<!-- Connectivity -->
					<div class="specs">
						<div class="title">
							<p>Connectivity</p>
						</div>
						<div class="line"></div>
						<div class="detail">
							<h4>LTE/LTE-A</h4>
							<p>4×4 MIMO, Supports up to DL Cat 18 / UL Cat 13(1.2Gbps / 150Mbps), depending on carrier support</p>
							<h4>Band</h4>
							<p>GSM：GSM850、GSM900、GSM1800、GSM1900</p>
							<p>WCDMA：B1、B2、B4、B5、B8、B9、B19</p>
							<p>CDMA：BC0(Roaming)</p>
							<p>LTE-FDD：B1, 2, 3, 4, 5, 7, 8, 12, 17, 18, 19, 20, 26</p>
							<p>LTE-TDD：B34, 38, 39, 40, 41, 46</p>
							<p>5G: n78</p>
							<p>MIMO：LTE：B1, 3, 41, 40 NR: n78
								（Note：Actual network and frequency band usage depends on local operator deployment. Hardware support 5G n78）</p>
							<h4>Wi-Fi</h4>
							<p>IEEE 802.11 a/b/g/n/ac/ax, 2.4G+5G, 2x2 MIMO</p>
							<h4>Bluetooth</h4>
							<p>Bluetooth 5.1, support aptX & aptX HD & LDAC & AAC & SBC</p>
							<h4>NFC</h4>
							<p>NFC enabled</p>
							<h4>Positioning</h4>
							<p>GPS (L1+L5 Dual Band), GLONASS, Galileo (E1+E5a Dual Band), Beidou, A-GPS</p>
						</div>
					</div>
					<div class="line"></div>
					<!-- Sensors -->
					<div class="specs">
						<div class="title">
							<p>Sensors</p>
						</div>
						<div class="line"></div>
						<div class="detail">
							<p>In-display Fingerprint Sensor</p>
							<p>Accelerometer</p>
							<p>Electronic Compass</p>
							<p>Gyroscope</p>
							<p>Ambient Light Sensor</p>
							<p>Proximity Sensor</p>
							<p>Sensor Core</p>
							<p>Laser Sensor</p>
							<p>Flicker-detect sensor</p>
							<p>Front RGB sensor</p>
						</div>
					</div>
					<div class="line"></div>
					<!-- Ports -->
					<div class="specs">
						<div class="title">
							<p>Ports</p>
						</div>
						<div class="line"></div>
						<div class="detail">
							<p>USB 3.1 GEN1</p>
							<p>Type-C</p>
							<p>Support standard Type-C earphone</p>
							<p>Dual nano-SIM slot</p>
						</div>
					</div>
					<div class="line"></div>
					<!-- Multimedia -->
					<div class="specs">
						<div class="title">
							<p>Multimedia</p>
						</div>
						<div class="line"></div>
						<div class="detail">
							<h4>Audio Supported Formats</h4>
							<p>Playback: MP3, AAC, AAC+, WMA, AMR-NB, AMR-WB, WAV, FLAC, APE, OGG, MID, M4A, IMY, AC3, EAC3, EAC3-JOC, AC4</p>
							<p>Recording: WAV, AAC, AMR</p>
							<h4>Video Supported Formats</h4>
							<p>Playback: MKV, MOV, MP4, H.265(HEVC), AVI, WMV, TS, 3GP, FLV, WEBM</p>
							<p>Recording: MP4</p>
							<h4>Image Supported Formats</h4>
							<p>Playback: JPEG、PNG、BMP、GIF、WEB、HEIF、HEIC、RAW</p>
							<p>Output: JPEG, DNG</p>
						</div>
					</div>
			</details>
		</div>
		<!-- Whats inside the Box -->
		<div class="dropdown" id="onelus8p">
			<details>
				<summary>In The Box</summary>
				<!-- Dimensions -->
				<div class="specs">
					<div class="title">
						<p>In the Box</p>
					</div>
					<div class="line"></div>
					<div class="detail">
						<p>OnePlus 8 Pro</p>
						<p>Warp Charge 30 Power Adapter</p>
						<p>Warp Type-C Cable (Support USB 2.0)</p>
						<p>Quick Start Guide</p>
						<p>Welcome Letter</p>
						<p>Safety Information and Warranty Card</p>
						<p>LOGO Sticker</p>
						<p>Case</p>
						<p>Screen Protector</p>
						<p>SIM Tray Ejector</p>
					</div>
				</div>
					<div class="Images">
						<img src="Images/8pro-in.jpg" alt="This Does not Support your browser">
					</div>
			</details>
		</div>
	</div>

	 <h3 style="text-align: center;">You Will Also like: </h3>

	<div class="mobiles inverted" id="mobiles">
		<div class="phones inverted">
			<img src="Images/Note20u1.png" class="inverted" alt="">
			<p>Samsung Galaxy Note20 Ultra</p>
			<p>&#x20B9 1,04,999</p>
		</div>
			<div class="phones inverted">
				<img src="Images/IP11PM.jfif" class="inverted" alt="">
				<p >iPhone 11 Pro Max</p>
				<p >&#x20B9 1,17,100</p>
			</div>
			<div class="phones inverted">
				<img src="Images/OP8P.png" class="inverted" alt="">
				<p >Oneplus 8 Pro</p>
				<p>&#x20B9 54,999</p>
			</div>
		<div class="phones inverted">
			<img src="Images/p4a.jpg" class="inverted" alt="">
			<p >Google Pixel 4a</p>
			<p >&#x20B9 29,999</p>
		</div>
	</div>


	<footer>
		<div class="footer">
			<div class="value">
				<span>GOKART</span>
			</div>
			<div class="value">
				<span>Get To Know Us</span>
				<p class="p"></p>
				<a href=""><p>About Us</p></a>
				<a href="#"><p>Careers</p></a>
			</div>
			<div class="value">
				<span>Contact Us</span>
				<p class="p"></p>
				<a href=""><p><i class="fa fa-phone" aria-hidden="true"></i> Service</p></a>
				<a href="#"><p><i class="fa fa-envelope" aria-hidden="true"></i> Email Us</p></a>
			</div>
			<div class="value">
				<span>Follow Us</span>
				<p class="p"></p>
				<a href="#"><p><i class="fa fa-instagram" aria-hidden="true"> Instagram</i></p></a>
				<a href="#"><p><i class="fa fa-facebook" aria-hidden="true"> Facebook</i></p></a>
				<a href="#"><p><i class="fa fa-twitter" aria-hidden="true"> Twitter</i></p></a>
			</div>
			<div class="value">
				<span>Quick Links</span>
				<p class="p"></p>
				<a href="#"><p>Gift</p></a>
				<a href="#"><p>Promo codes</p></a>
			</div>
		</div>
	</footer>



	 <script type="text/javascript">
		var clas1 = document.getElementsByClassName('cont')
		console.log(clas1)
		var clas4 = document.getElementsByClassName('dropdown')
		console.log(clas4)
		var clas = document.querySelectorAll(".cont")
		console.log(clas)
		var clas2 = document.querySelectorAll(".cont .dropdown")
		console.log(clas2)
		var clas3 = document.querySelectorAll(".cont .dropdown1")
		console.log(clas)
		var cal = localStorage.getItem("myValue");
		console.log(cal)


		for(var i=0; i<= clas1.length; i++){
			if(clas[i].id == cal){
				clas[i].style.display = "inline";
			}
		}


		var id = clas4.id;
		console.log(id);

	</script>
	<script type="text/javascript">

		let thumbnails = document.getElementsByClassName('Product')
		let big = document.getElementsByClassName('big');


		let activeImages = document.getElementsByClassName('active')

		for (var i=0; i < thumbnails.length; i++){

			thumbnails[i].addEventListener('click', function(){


				if (activeImages.length > 0){
					activeImages[0].classList.remove('active')
				}


				this.classList.add('active')
				for(var i=0; i<= big.length; i++){
					big[i].src = this.src
				}

			})
		}



	</script>
</body>
</html>
